/**
 * @author  Hamza Waqas <hamzawaqas@live.com>
 * @since   1/14/14
 */
exports = module.exports = require('./lib/main');